package com.example.dbsibanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Expenditure_Details extends AppCompatActivity {

    private Button btn_transport;
    private Button btn_food;
    private Button btn_others;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_expenditure);




        btn_transport = findViewById(R.id.btn_transport);
        btn_food = findViewById(R.id.btn_food);
        btn_others = findViewById(R.id.btn_others);

        btn_transport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Expenditure_Details.this, TabOne.class));
            }
        });

        btn_food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Expenditure_Details.this, TabTwo.class));
            }
        });

        btn_others.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Expenditure_Details.this, TabThree.class));
            }
        });

    }
}
