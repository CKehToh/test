package com.example.dbsibanking;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class Payment extends AppCompatActivity{

    private Button btn_other, btn_overseas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Button btn_other = findViewById(R.id.others);
        Button btn_overseas = findViewById(R.id.overseas);

        btn_other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Payment.this, Transaction_Activity.class));
            }
        });

        btn_overseas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Payment.this, Transaction_Activity.class));
            }
        });








    }
}
