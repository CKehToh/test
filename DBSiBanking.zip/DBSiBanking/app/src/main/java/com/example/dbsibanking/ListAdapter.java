package com.example.dbsibanking;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class ListAdapter extends BaseAdapter {

    Context context;
    String transactionList[];
    LayoutInflater inflater;

    public ListAdapter(Context applicationContext, String[] transactionList) {
        this.context = context;
        this.transactionList = transactionList;
        inflater = (LayoutInflater.from(applicationContext));
    }

    @Override
    public int getCount() {
        return transactionList.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.activity_transaction, null);
        TextView transaction = (TextView) view.findViewById(R.id.trans1);
        transaction.setText(transactionList[i]);
        return view;
    }


}



